import { useLanguage } from '@/i18n/LanguageContext';
import { Award, Users, Clock, Target } from 'lucide-react';

export function AboutPage() {
  const { t, language } = useLanguage();

  const values = [
    {
      icon: Award,
      title: language === 'fi' ? 'Laatu' : 'Kvalitet',
      description: language === 'fi' 
        ? 'Emme tingi laadusta. Jokainen työ tehdään parhaalla mahdollisella tavalla.'
        : 'Vi kompromissar inte om kvalitet. Varje jobb görs på bästa möjliga sätt.',
      color: '#e91e8c',
    },
    {
      icon: Users,
      title: language === 'fi' ? 'Asiakaslähtöisyys' : 'Kundorientering',
      description: language === 'fi'
        ? 'Asiakkaan tyytyväisyys on meille kaikki kaikessa.'
        : 'Kundnöjdhet är allt för oss.',
      color: '#00d4ff',
    },
    {
      icon: Clock,
      title: language === 'fi' ? 'Luotettavuus' : 'Pålitlighet',
      description: language === 'fi'
        ? 'Pidämme aina kiinni sovituista aikatauluista ja lupauksista.'
        : 'Vi håller alltid tidsplaner och löften.',
      color: '#ff9500',
    },
    {
      icon: Target,
      title: language === 'fi' ? 'Ammattitaito' : 'Yrkeskunnande',
      description: language === 'fi'
        ? 'Jatkuva kehittyminen ja uusien tekniikoiden oppiminen.'
        : 'Kontinuerlig utveckling och inlärning av nya tekniker.',
      color: '#C9A961',
    },
  ];

  const brands = [
    'Gtechniq', 'CarPro', 'Chemical Guys', 'Meguiars', 
    'Auto Finesse', 'Rupes', 'Flex', 'Koch-Chemie'
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#C9A961]/10 rounded-full blur-[200px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-2 rounded-full bg-[#C9A961]/10 text-[#C9A961] text-sm font-medium mb-4">
            PoweraFix
          </span>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            {t.about.title}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.about.subtitle}
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Image */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#e91e8c]/20 to-[#00d4ff]/20 rounded-3xl blur-2xl" />
              <img
                src="/images/powerafix-character.png"
                alt="PoweraFix"
                className="relative rounded-3xl w-full"
              />
            </div>

            {/* Content */}
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">
                {language === 'fi' ? 'Meidän tarinamme' : 'Vår historia'}
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed mb-6">
                {t.about.story}
              </p>
              <p className="text-gray-400 leading-relaxed mb-8">
                {language === 'fi'
                  ? 'Olemme erikoistuneet yksityiskohtaiseen autonhoitoon, jossa jokainen yksityiskohta on tärkeä. Käytämme vain parhaita tuotteita ja tekniikoita varmistaaksemme, että autosi saa sen hoidon, jonka se ansaitsee.'
                  : 'Vi är specialiserade på detaljerad fordonsvård där varje detalj är viktig. Vi använder endast de bästa produkterna och teknikerna för att säkerställa att din bil får den vård den förtjänar.'}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6">
                {[
                  { value: '500+', label: language === 'fi' ? 'Auto' : 'Bilar' },
                  { value: '5+', label: language === 'fi' ? 'Vuotta' : 'År' },
                  { value: '100%', label: language === 'fi' ? 'Tyytyväisyys' : 'Nöjdhet' },
                ].map((stat, index) => (
                  <div key={index} className="text-center p-4 rounded-xl bg-white/5">
                    <div className="text-2xl font-bold gradient-text">{stat.value}</div>
                    <div className="text-gray-400 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="section-padding bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            {language === 'fi' ? 'Arvomme' : 'Våra värderingar'}
          </h2>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-2xl p-6 border border-white/5 text-center card-hover"
              >
                <div 
                  className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center"
                  style={{ backgroundColor: `${value.color}15` }}
                >
                  <value.icon className="w-8 h-8" style={{ color: value.color }} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{value.title}</h3>
                <p className="text-gray-400 text-sm">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brands Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            {t.about.brands}
          </h2>
          
          <div className="flex flex-wrap justify-center gap-4">
            {brands.map((brand, index) => (
              <div
                key={index}
                className="px-6 py-3 rounded-full bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
              >
                {brand}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
