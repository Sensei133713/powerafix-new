import { useLanguage } from '@/i18n/LanguageContext';
import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle, Instagram, Facebook } from 'lucide-react';

export function ContactPage() {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', phone: '', service: '', message: '' });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const services = language === 'fi' ? [
    { value: '', label: 'Valitse palvelu' },
    { value: 'interior', label: 'Sisäpuhdistus' },
    { value: 'exterior', label: 'Ulkopuhdistus' },
    { value: 'coating', label: 'Keraamiset pinnoitteet' },
    { value: 'special', label: 'Erikoispalvelut' },
    { value: 'other', label: 'Muu' },
  ] : [
    { value: '', label: 'Välj tjänst' },
    { value: 'interior', label: 'Invändig rengöring' },
    { value: 'exterior', label: 'Utvändig tvätt' },
    { value: 'coating', label: 'Keramiska beläggningar' },
    { value: 'special', label: 'Specialtjänster' },
    { value: 'other', label: 'Annat' },
  ];

  const hours = language === 'fi' ? [
    { day: 'Maanantai - Perjantai', time: '08:00 - 18:00' },
    { day: 'Lauantai', time: '09:00 - 16:00' },
    { day: 'Sunnuntai', time: 'Sopimuksen mukaan' },
  ] : [
    { day: 'Måndag - Fredag', time: '08:00 - 18:00' },
    { day: 'Lördag', time: '09:00 - 16:00' },
    { day: 'Söndag', time: 'Enligt överenskommelse' },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#e91e8c]/10 rounded-full blur-[200px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-2 rounded-full bg-[#e91e8c]/10 text-[#e91e8c] text-sm font-medium mb-4">
            PoweraFix
          </span>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            {t.contact.title}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.contact.subtitle}
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border border-white/5">
              <h2 className="text-2xl font-bold text-white mb-6">
                {t.common.sendMessage}
              </h2>

              {isSubmitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
                    <CheckCircle className="w-8 h-8 text-green-500" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">
                    {t.contact.form.success}
                  </h3>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">{t.contact.form.name}</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#e91e8c] transition-colors"
                      placeholder={t.contact.form.name}
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">{t.contact.form.email}</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#e91e8c] transition-colors"
                        placeholder="email@esimerkki.com"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">{t.contact.form.phone}</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#e91e8c] transition-colors"
                        placeholder="+358 40 123 4567"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">{t.contact.form.service}</label>
                    <select
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#e91e8c] transition-colors appearance-none cursor-pointer"
                    >
                      {services.map((service) => (
                        <option key={service.value} value={service.value} className="bg-[#1a1a1a]">
                          {service.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">{t.contact.form.message}</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={4}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:border-[#e91e8c] transition-colors resize-none"
                      placeholder={language === 'fi' ? 'Kirjoita viestisi tähän...' : 'Skriv ditt meddelande här...'}
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full btn-primary flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-white font-semibold"
                  >
                    <Send className="w-5 h-5" />
                    {t.contact.form.submit}
                  </button>
                </form>
              )}
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              {/* Contact Details */}
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border border-white/5">
                <h2 className="text-2xl font-bold text-white mb-6">
                  {t.footer.contact}
                </h2>
                
                <ul className="space-y-4">
                  <li>
                    <a
                      href="tel:+46720256828"
                      className="flex items-center gap-4 text-gray-400 hover:text-[#e91e8c] transition-colors"
                    >
                      <div className="w-12 h-12 rounded-xl bg-[#e91e8c]/10 flex items-center justify-center">
                        <Phone className="w-5 h-5 text-[#e91e8c]" />
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Ruotsi</div>
                        <div className="text-white">+46 72 025 68 28</div>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a
                      href="tel:+358465549098"
                      className="flex items-center gap-4 text-gray-400 hover:text-[#e91e8c] transition-colors"
                    >
                      <div className="w-12 h-12 rounded-xl bg-[#e91e8c]/10 flex items-center justify-center">
                        <Phone className="w-5 h-5 text-[#e91e8c]" />
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Suomi</div>
                        <div className="text-white">+358 46 554 90 98</div>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a
                      href="mailto:info@powerafix.com"
                      className="flex items-center gap-4 text-gray-400 hover:text-[#00d4ff] transition-colors"
                    >
                      <div className="w-12 h-12 rounded-xl bg-[#00d4ff]/10 flex items-center justify-center">
                        <Mail className="w-5 h-5 text-[#00d4ff]" />
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Email</div>
                        <div className="text-white">info@powerafix.com</div>
                      </div>
                    </a>
                  </li>
                  <li className="flex items-center gap-4 text-gray-400">
                    <div className="w-12 h-12 rounded-xl bg-[#ff9500]/10 flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-[#ff9500]" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">{language === 'fi' ? 'Sijainti' : 'Plats'}</div>
                      <div className="text-white">PoweraFix, Ruotsi / Suomi</div>
                    </div>
                  </li>
                </ul>
              </div>

              {/* Opening Hours */}
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border border-white/5">
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                  <Clock className="w-6 h-6 text-[#e91e8c]" />
                  {t.contact.hours}
                </h2>
                
                <ul className="space-y-3">
                  {hours.map((item, index) => (
                    <li key={index} className="flex justify-between items-center py-2 border-b border-white/5 last:border-0">
                      <span className="text-gray-400">{item.day}</span>
                      <span className="text-white font-medium">{item.time}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Social Media */}
              <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border border-white/5">
                <h2 className="text-2xl font-bold text-white mb-6">
                  {t.footer.followUs}
                </h2>
                
                <div className="flex gap-4">
                  <a
                    href="https://instagram.com/powerafix1"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 px-6 py-4 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:opacity-90 transition-opacity"
                  >
                    <Instagram className="w-5 h-5" />
                    <span>@powerafix1</span>
                  </a>
                  <a
                    href="https://facebook.com/powerafix"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 px-6 py-4 rounded-xl bg-[#1877F2] text-white hover:opacity-90 transition-opacity"
                  >
                    <Facebook className="w-5 h-5" />
                    <span>powerafix</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
