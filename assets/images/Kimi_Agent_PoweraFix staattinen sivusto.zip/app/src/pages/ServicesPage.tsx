import { useLanguage } from '@/i18n/LanguageContext';
import { Sparkles, Car, Shield, Wrench, Check, ArrowRight } from 'lucide-react';

interface ServicesPageProps {
  onPageChange: (page: string) => void;
}

export function ServicesPage({ onPageChange }: ServicesPageProps) {
  const { t, language } = useLanguage();

  const services = [
    {
      id: 'interior',
      icon: Sparkles,
      title: t.services.interior.title,
      description: t.services.interior.description,
      color: '#e91e8c',
      features: language === 'fi' ? [
        'Imurointi ja pölyjen poisto',
        'Penkkien ja mattojen pesu',
        'Kojelaudan ja muoviosien hoito',
        'Ikkunoiden puhdistus sisältä',
        'Hajunpoisto ja raikastus',
      ] : [
        'Dammsugning och dammborttagning',
        'Tvätt av säten och mattor',
        'Vård av instrumentbräda och plastdelar',
        'Fönsterputs invändigt',
        'Luktborttagning och uppfräschning',
      ],
      price: 'alk. 379 kr',
    },
    {
      id: 'exterior',
      icon: Car,
      title: t.services.exterior.title,
      description: t.services.exterior.description,
      color: '#00d4ff',
      features: language === 'fi' ? [
        'Käsinpesu ilman kovia harjoja',
        'Vanteiden puhdistus',
        'Renkaiden hoito',
        'Lasinpuhdistus ulkoa',
        'Kuivaus mikrokuidulla',
      ] : [
        'Handtvätt utan hårda borstar',
        'Rengöring av fälgar',
        'Däckvård',
        'Fönsterputs utvändigt',
        'Torkning med mikrofiber',
      ],
      price: 'alk. 379 kr',
    },
    {
      id: 'coating',
      icon: Shield,
      title: t.services.coating.title,
      description: t.services.coating.description,
      color: '#ff9500',
      features: language === 'fi' ? [
        'Maalipinnan syväpuhdistus',
        'Kiillotus ennen pinnoitusta',
        'Keraamisen pinnoitteen levitys',
        'Kovettuminen 24h',
        'Kestävyys jopa 2 vuotta',
      ] : [
        'Djuprengöring av lacken',
        'Polering före beläggning',
        'Applicering av keramisk beläggning',
        'Härdning 24h',
        'Hållbarhet upp till 2 år',
      ],
      price: 'alk. 1990 kr',
    },
    {
      id: 'special',
      icon: Wrench,
      title: t.services.special.title,
      description: t.services.special.description,
      color: '#C9A961',
      features: language === 'fi' ? [
        'Maalipinnan kiillotus',
        'Vahaukset',
        'Nahkapenkkien hoito',
        'Moottoritilan puhdistus',
        'Yksilölliset toiveet',
      ] : [
        'Lackpolering',
        'Vaxning',
        'Vård av lädersäten',
        'Rengöring av motorrum',
        'Individuella önskemål',
      ],
      price: language === 'fi' ? 'Kysy tarjous' : 'Begär offert',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#e91e8c]/10 rounded-full blur-[200px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-2 rounded-full bg-[#e91e8c]/10 text-[#e91e8c] text-sm font-medium mb-4">
            PoweraFix
          </span>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            {t.services.title}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.services.subtitle}
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {services.map((service) => (
              <div
                key={service.id}
                className="relative bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border border-white/5 overflow-hidden group"
              >
                {/* Background glow */}
                <div 
                  className="absolute -top-20 -right-20 w-40 h-40 rounded-full blur-[80px] opacity-30 group-hover:opacity-50 transition-opacity"
                  style={{ backgroundColor: service.color }}
                />

                {/* Header */}
                <div className="relative flex items-start gap-4 mb-6">
                  <div 
                    className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${service.color}15` }}
                  >
                    <service.icon className="w-8 h-8" style={{ color: service.color }} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{service.title}</h3>
                    <p className="text-gray-400">{service.description}</p>
                  </div>
                </div>

                {/* Features */}
                <ul className="relative space-y-3 mb-8">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <div 
                        className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${service.color}20` }}
                      >
                        <Check className="w-3 h-3" style={{ color: service.color }} />
                      </div>
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Price & CTA */}
                <div className="relative flex items-center justify-between pt-6 border-t border-white/5">
                  <div>
                    <span className="text-gray-500 text-sm">{t.pricing.from}</span>
                    <div className="text-2xl font-bold" style={{ color: service.color }}>
                      {service.price}
                    </div>
                  </div>
                  <button
                    onClick={() => onPageChange('contact')}
                    className="flex items-center gap-2 px-6 py-3 rounded-full font-semibold text-white transition-all hover:scale-105"
                    style={{ backgroundColor: service.color }}
                  >
                    {t.pricing.bookService}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
