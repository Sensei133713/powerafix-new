import { useLanguage } from '@/i18n/LanguageContext';
import { useState } from 'react';

export function GalleryPage() {
  const { t } = useLanguage();
  const [activeFilter, setActiveFilter] = useState('all');

  const filters = [
    { id: 'all', label: t.gallery.filter.all },
    { id: 'interior', label: t.gallery.filter.interior },
    { id: 'exterior', label: t.gallery.filter.exterior },
    { id: 'coating', label: t.gallery.filter.coating },
  ];

  const galleryItems = [
    {
      id: 1,
      category: 'interior',
      image: '/images/powerafix-banner.jpg',
      title: 'Sisäpuhdistus - Audi',
    },
    {
      id: 2,
      category: 'exterior',
      image: '/images/powerafix-swedish.jpg',
      title: 'Ulkopuhdistus - BMW',
    },
    {
      id: 3,
      category: 'coating',
      image: '/images/powerafix-banner2.jpg',
      title: 'Keraaminen pinnoite - Mercedes',
    },
    {
      id: 4,
      category: 'interior',
      image: '/images/powerafix-logo-full.png',
      title: 'Sisäfixaus - Volvo',
    },
    {
      id: 5,
      category: 'exterior',
      image: '/images/powerafix-character.png',
      title: 'Käsipesu - Tesla',
    },
    {
      id: 6,
      category: 'coating',
      image: '/images/powerafix-banner.jpg',
      title: 'Vahaus - Porsche',
    },
  ];

  const filteredItems = activeFilter === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === activeFilter);

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a]" />
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#00d4ff]/10 rounded-full blur-[200px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-2 rounded-full bg-[#00d4ff]/10 text-[#00d4ff] text-sm font-medium mb-4">
            PoweraFix
          </span>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            {t.gallery.title}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.gallery.subtitle}
          </p>
        </div>
      </section>

      {/* Gallery */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-6 py-3 rounded-full font-medium transition-all ${
                  activeFilter === filter.id
                    ? 'bg-[#e91e8c] text-white'
                    : 'bg-[#1a1a1a] text-gray-400 hover:text-white hover:bg-[#2a2a2a]'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item, index) => (
              <div
                key={item.id}
                className="group relative aspect-[4/3] rounded-2xl overflow-hidden cursor-pointer"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Title */}
                <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="text-white font-semibold text-lg">{item.title}</h3>
                  <span className="text-[#e91e8c] text-sm">
                    {filters.find(f => f.id === item.category)?.label}
                  </span>
                </div>

                {/* Corner accent */}
                <div className="absolute top-4 right-4 w-10 h-10 rounded-full bg-[#e91e8c]/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
