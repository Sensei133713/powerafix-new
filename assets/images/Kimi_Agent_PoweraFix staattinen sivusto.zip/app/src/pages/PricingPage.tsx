import { useLanguage } from '@/i18n/LanguageContext';
import { Check, Star, ArrowRight } from 'lucide-react';

interface PricingPageProps {
  onPageChange: (page: string) => void;
}

export function PricingPage({ onPageChange }: PricingPageProps) {
  const { t, language } = useLanguage();

  const pricingPlans = [
    {
      name: language === 'fi' ? 'Peruspesu' : 'Grundtvätt',
      description: language === 'fi' ? 'Käsinpesu ulkoa' : 'Handtvätt utvändigt',
      carPrice: '379 kr',
      vanPrice: '479 kr',
      features: language === 'fi' ? [
        'Käsinpesu ilman kovia harjoja',
        'Vanteiden puhdistus',
        'Renkaiden hoito',
        'Lasinpuhdistus',
        'Kuivaus mikrokuidulla',
      ] : [
        'Handtvätt utan hårda borstar',
        'Rengöring av fälgar',
        'Däckvård',
        'Fönsterputs',
        'Torkning med mikrofiber',
      ],
      popular: false,
      color: '#00d4ff',
    },
    {
      name: language === 'fi' ? 'Sisä & Ulko' : 'Invändig & Utvändig',
      description: language === 'fi' ? 'Täydellinen puhdistus' : 'Komplett rengöring',
      carPrice: '749 kr',
      vanPrice: '949 kr',
      features: language === 'fi' ? [
        'Kaikki peruspesun palvelut',
        'Sisätilojen imurointi',
        'Penkkien ja mattojen pesu',
        'Kojelaudan hoito',
        'Hajunpoisto',
      ] : [
        'Alla tjänster från grundtvätt',
        'Dammsugning av interiör',
        'Tvätt av säten och mattor',
        'Vård av instrumentbräda',
        'Luktborttagning',
      ],
      popular: true,
      color: '#e91e8c',
    },
    {
      name: language === 'fi' ? 'Premium' : 'Premium',
      description: language === 'fi' ? 'Keraaminen pinnoite' : 'Keramisk beläggning',
      carPrice: '1990 kr',
      vanPrice: '2490 kr',
      features: language === 'fi' ? [
        'Kaikki Sisä & Ulko -palvelut',
        'Maalipinnan syväpuhdistus',
        'Kiillotus',
        'Keraaminen pinnoite',
        '2 vuoden takuu',
      ] : [
        'Alla tjänster från Invändig & Utvändig',
        'Djuprengöring av lacken',
        'Polering',
        'Keramisk beläggning',
        '2 års garanti',
      ],
      popular: false,
      color: '#ff9500',
    },
  ];

  const additionalServices = language === 'fi' ? [
    { name: 'Vahaus', price: 'alk. 590 kr' },
    { name: 'Kiillotus', price: 'alk. 890 kr' },
    { name: 'Nahkapenkkien hoito', price: 'alk. 450 kr' },
    { name: 'Moottoritilan puhdistus', price: 'alk. 350 kr' },
    { name: 'Hajunpoisto (ozon)', price: 'alk. 290 kr' },
  ] : [
    { name: 'Vaxning', price: 'från 590 kr' },
    { name: 'Polering', price: 'från 890 kr' },
    { name: 'Vård av lädersäten', price: 'från 450 kr' },
    { name: 'Rengöring av motorrum', price: 'från 350 kr' },
    { name: 'Luktborttagning (ozon)', price: 'från 290 kr' },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#ff9500]/10 rounded-full blur-[200px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-2 rounded-full bg-[#ff9500]/10 text-[#ff9500] text-sm font-medium mb-4">
            PoweraFix
          </span>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            {t.pricing.title}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.pricing.subtitle}
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <div
                key={index}
                className={`relative bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border ${
                  plan.popular ? 'border-[#e91e8c]/50' : 'border-white/5'
                } overflow-hidden`}
              >
                {/* Popular badge */}
                {plan.popular && (
                  <div className="absolute top-0 right-0 bg-[#e91e8c] text-white text-xs font-bold px-4 py-2 rounded-bl-xl flex items-center gap-1">
                    <Star className="w-3 h-3 fill-current" />
                    {language === 'fi' ? 'Suosituin' : 'Mest populär'}
                  </div>
                )}

                {/* Header */}
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                  <p className="text-gray-400">{plan.description}</p>
                </div>

                {/* Prices */}
                <div className="space-y-3 mb-8 pb-8 border-b border-white/5">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">{t.pricing.car}</span>
                    <span className="text-2xl font-bold" style={{ color: plan.color }}>
                      {plan.carPrice}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">{t.pricing.van}</span>
                    <span className="text-2xl font-bold" style={{ color: plan.color }}>
                      {plan.vanPrice}
                    </span>
                  </div>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <div 
                        className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${plan.color}20` }}
                      >
                        <Check className="w-3 h-3" style={{ color: plan.color }} />
                      </div>
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <button
                  onClick={() => onPageChange('contact')}
                  className={`w-full flex items-center justify-center gap-2 px-6 py-4 rounded-full font-semibold text-white transition-all hover:scale-105 ${
                    plan.popular ? 'btn-primary' : 'bg-white/10 hover:bg-white/20'
                  }`}
                >
                  {t.pricing.bookService}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Additional Services */}
          <div className="mt-20">
            <h2 className="text-2xl font-bold text-white text-center mb-8">
              {t.pricing.packages}
            </h2>
            <div className="bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-3xl p-8 border border-white/5">
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {additionalServices.map((service, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <span className="text-gray-300">{service.name}</span>
                    <span className="text-[#e91e8c] font-semibold">{service.price}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
