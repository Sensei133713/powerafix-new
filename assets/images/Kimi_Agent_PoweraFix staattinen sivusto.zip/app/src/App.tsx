import { useState } from 'react';
import { LanguageProvider } from '@/i18n/LanguageContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Hero } from '@/sections/Hero';
import { Services } from '@/sections/Services';
import { BeforeAfter } from '@/sections/BeforeAfter';
import { USP } from '@/sections/USP';
import { Testimonials } from '@/sections/Testimonials';
import { ServicesPage } from '@/pages/ServicesPage';
import { GalleryPage } from '@/pages/GalleryPage';
import { PricingPage } from '@/pages/PricingPage';
import { AboutPage } from '@/pages/AboutPage';
import { ContactPage } from '@/pages/ContactPage';

function HomePage({ onPageChange }: { onPageChange: (page: string) => void }) {
  return (
    <>
      <Hero onPageChange={onPageChange} />
      <Services onPageChange={onPageChange} />
      <BeforeAfter />
      <USP />
      <Testimonials />
    </>
  );
}

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const handlePageChange = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPageChange={handlePageChange} />;
      case 'services':
        return <ServicesPage onPageChange={handlePageChange} />;
      case 'gallery':
        return <GalleryPage />;
      case 'pricing':
        return <PricingPage onPageChange={handlePageChange} />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage onPageChange={handlePageChange} />;
    }
  };

  return (
    <LanguageProvider>
      <div className="min-h-screen bg-[#0a0a0a]">
        <Header currentPage={currentPage} onPageChange={handlePageChange} />
        <main>
          {renderPage()}
        </main>
        <Footer onPageChange={handlePageChange} />
      </div>
    </LanguageProvider>
  );
}

export default App;
