export type Language = 'fi' | 'sv';

export interface Translations {
  // Navigation
  nav: {
    home: string;
    services: string;
    gallery: string;
    pricing: string;
    about: string;
    contact: string;
    bookNow: string;
  };
  // Hero
  hero: {
    title: string;
    subtitle: string;
    description: string;
    ctaPrimary: string;
    ctaSecondary: string;
  };
  // Services
  services: {
    title: string;
    subtitle: string;
    interior: {
      title: string;
      description: string;
    };
    exterior: {
      title: string;
      description: string;
    };
    coating: {
      title: string;
      description: string;
    };
    special: {
      title: string;
      description: string;
    };
    cta: string;
  };
  // Before/After
  beforeAfter: {
    title: string;
    subtitle: string;
    before: string;
    after: string;
  };
  // USP
  usp: {
    title: string;
    expertise: {
      title: string;
      description: string;
    };
    products: {
      title: string;
      description: string;
    };
    guarantee: {
      title: string;
      description: string;
    };
  };
  // Testimonials
  testimonials: {
    title: string;
    subtitle: string;
  };
  // Pricing
  pricing: {
    title: string;
    subtitle: string;
    from: string;
    car: string;
    van: string;
    packages: string;
    bookService: string;
    contactForQuote: string;
  };
  // Gallery
  gallery: {
    title: string;
    subtitle: string;
    filter: {
      all: string;
      interior: string;
      exterior: string;
      coating: string;
    };
  };
  // About
  about: {
    title: string;
    subtitle: string;
    story: string;
    brands: string;
  };
  // Contact
  contact: {
    title: string;
    subtitle: string;
    form: {
      name: string;
      email: string;
      phone: string;
      service: string;
      message: string;
      submit: string;
      success: string;
    };
    hours: string;
    booking: string;
  };
  // Footer
  footer: {
    slogan: string;
    quickLinks: string;
    contact: string;
    followUs: string;
    rights: string;
  };
  // Common
  common: {
    readMore: string;
    learnMore: string;
    freeQuote: string;
    seePricing: string;
    callUs: string;
    sendMessage: string;
  };
}

export const translations: Record<Language, Translations> = {
  fi: {
    nav: {
      home: 'Etusivu',
      services: 'Palvelut',
      gallery: 'Galleria',
      pricing: 'Hinnasto',
      about: 'Yritys',
      contact: 'Yhteystiedot',
      bookNow: 'Varaa aika',
    },
    hero: {
      title: 'Autosi ansaitsee enemmän kuin konepesun',
      subtitle: 'PoweraFix - Auton yksityiskohtainen hoito',
      description: 'Käsin pesty. Huolella tehty. Ei kovia harjoja. Ei hutilointia. Vain kiiltävä lopputulos.',
      ctaPrimary: 'Varaa aika nyt',
      ctaSecondary: 'Pyydä ilmainen arvio',
    },
    services: {
      title: 'Palvelumme',
      subtitle: 'Ammattitaitoista autonhoitoa vuosien kokemuksella',
      interior: {
        title: 'Sisäpuhdistus',
        description: 'Perusteellinen sisätilojen puhdistus, imurointi, pesu ja hoito. Penkit, matot, kojelauta - kaikki huolellisesti käsiteltynä.',
      },
      exterior: {
        title: 'Ulkopuhdistus',
        description: 'Käsinpesu ilman kovia harjoja. Turvallinen maalipinnalle, yksilöllinen ja tarkka pesu syvemmällä kiillolla.',
      },
      coating: {
        title: 'Keraamiset pinnoitteet',
        description: 'Kestävä suoja maalipinnalle. Pitkäaikainen kiilto ja suoja sääolosuhteilta sekä likaantumiselta.',
      },
      special: {
        title: 'Erikoispalvelut',
        description: 'Kiillotukset, vahaukset, sisäfixaukset ja muut erikoistyöt. Kysy lisää tarpeidesi mukaan!',
      },
      cta: 'Katso kaikki palvelut',
    },
    beforeAfter: {
      title: 'Ennen & Jälkeen',
      subtitle: 'Tuloksia, jotka puhuvat puolestaan',
      before: 'Ennen',
      after: 'Jälkeen',
    },
    usp: {
      title: 'Miksi valita PoweraFix?',
      expertise: {
        title: 'Ammattitaito',
        description: 'Vuosien kokemus autonhoidosta. Jokainen auto käsitellään kuin omaamme.',
      },
      products: {
        title: 'Premium-tuotteet',
        description: 'Käytämme vain laadukkaimpia ammattituotteita parhaan lopputuloksen takaamiseksi.',
      },
      guarantee: {
        title: 'Tyytyväisyystakuu',
        description: 'Et ole tyytyväinen? Emme ole valmiita. Takaamme laadun jokaisessa työssä.',
      },
    },
    testimonials: {
      title: 'Asiakkaat sanovat',
      subtitle: 'Katso, mitä asiakkaamme ajattelevat',
    },
    pricing: {
      title: 'Hinnasto',
      subtitle: 'Selkeät hinnat, ei piilokuluja',
      from: 'alk.',
      car: 'Henkilöauto',
      van: 'Pakettiauto / SUV',
      packages: 'Pakettitarjoukset',
      bookService: 'Varaa tämä palvelu',
      contactForQuote: 'Pyydä tarjous',
    },
    gallery: {
      title: 'Galleria',
      subtitle: 'Tutustu töihimme',
      filter: {
        all: 'Kaikki',
        interior: 'Sisäpuhdistus',
        exterior: 'Ulkopuhdistus',
        coating: 'Pinnoitteet',
      },
    },
    about: {
      title: 'Meistä',
      subtitle: 'PoweraFixin tarina',
      story: 'PoweraFix on perustettu intohimosta autoja kohtaan. Uskomme, että jokainen auto ansaitsee parasta mahdollista hoitoa. Vuosien kokemuksella olemme kehittäneet menetelmiä, jotka tuottavat kiiltäviä tuloksia ilman kompromisseja.',
      brands: 'Käyttämämme tuotemerkit',
    },
    contact: {
      title: 'Yhteystiedot',
      subtitle: 'Ota yhteyttä ja varaa aika',
      form: {
        name: 'Nimi',
        email: 'Sähköposti',
        phone: 'Puhelinnumero',
        service: 'Valitse palvelu',
        message: 'Viesti',
        submit: 'Lähetä viesti',
        success: 'Viesti lähetetty! Olemme yhteydessä pian.',
      },
      hours: 'Aukioloajat',
      booking: 'Varaus',
    },
    footer: {
      slogan: 'Autosi ansaitsee parasta',
      quickLinks: 'Pikalinkit',
      contact: 'Yhteystiedot',
      followUs: 'Seuraa meitä',
      rights: 'Kaikki oikeudet pidätetään.',
    },
    common: {
      readMore: 'Lue lisää',
      learnMore: 'Lue lisää',
      freeQuote: 'Ilmainen arvio',
      seePricing: 'Katso hinnasto',
      callUs: 'Soita meille',
      sendMessage: 'Lähetä viesti',
    },
  },
  sv: {
    nav: {
      home: 'Startsida',
      services: 'Tjänster',
      gallery: 'Galleri',
      pricing: 'Prislista',
      about: 'Om oss',
      contact: 'Kontakt',
      bookNow: 'Boka tid',
    },
    hero: {
      title: 'Din bil förtjänar mer än en biltvätt',
      subtitle: 'PoweraFix - Fordonsvård i detalj',
      description: 'Handtvättad. Gjord med omsorg. Inga hårda borstar. Inga genvägar. Bara ett glänsande resultat.',
      ctaPrimary: 'Boka tid nu',
      ctaSecondary: 'Begär gratis värdering',
    },
    services: {
      title: 'Våra tjänster',
      subtitle: 'Professionell fordonsvård med års erfarenhet',
      interior: {
        title: 'Invändig rengöring',
        description: 'Grundlig rengöring av interiören, dammsugning, tvätt och vård. Säten, mattor, instrumentbräda - allt noggrant behandlat.',
      },
      exterior: {
        title: 'Utvändig tvätt',
        description: 'Handtvätt utan hårda borstar. Säker för lacken, individuell och noggrann tvätt med djupare glans.',
      },
      coating: {
        title: 'Keramiska beläggningar',
        description: 'Hållbart skydd för lacken. Långvarig glans och skydd mot väderförhållanden och smuts.',
      },
      special: {
        title: 'Specialtjänster',
        description: 'Polering, vaxning, invändig fix och andra specialarbeten. Fråga mer enligt dina behov!',
      },
      cta: 'Se alla tjänster',
    },
    beforeAfter: {
      title: 'Före & Efter',
      subtitle: 'Resultat som talar för sig själva',
      before: 'Före',
      after: 'Efter',
    },
    usp: {
      title: 'Varför välja PoweraFix?',
      expertise: {
        title: 'Yrkeskunnande',
        description: 'Års erfarenhet av fordonsvård. Varje bil behandlas som om den vore vår egen.',
      },
      products: {
        title: 'Premium-produkter',
        description: 'Vi använder endast de högkvalitativaste professionella produkterna för att garantera bästa resultat.',
      },
      guarantee: {
        title: 'Nöjdhetsgaranti',
        description: 'Inte nöjd? Vi är inte klara. Vi garanterar kvalitet i varje jobb.',
      },
    },
    testimonials: {
      title: 'Kunderna säger',
      subtitle: 'Se vad våra kunder tycker',
    },
    pricing: {
      title: 'Prislista',
      subtitle: 'Klara priser, inga dolda kostnader',
      from: 'från',
      car: 'Personbil',
      van: 'Transportbil / SUV',
      packages: 'Paketerbjudanden',
      bookService: 'Boka denna tjänst',
      contactForQuote: 'Begär offert',
    },
    gallery: {
      title: 'Galleri',
      subtitle: 'Utforska vårt arbete',
      filter: {
        all: 'Alla',
        interior: 'Invändig',
        exterior: 'Utvändig',
        coating: 'Beläggningar',
      },
    },
    about: {
      title: 'Om oss',
      subtitle: 'PoweraFix historia',
      story: 'PoweraFix grundades av passion för bilar. Vi tror att varje bil förtjänar den bästa möjliga vården. Med års erfarenhet har vi utvecklat metoder som producerar glänsande resultat utan kompromisser.',
      brands: 'Varumärken vi använder',
    },
    contact: {
      title: 'Kontakt',
      subtitle: 'Kontakta oss och boka tid',
      form: {
        name: 'Namn',
        email: 'E-post',
        phone: 'Telefonnummer',
        service: 'Välj tjänst',
        message: 'Meddelande',
        submit: 'Skicka meddelande',
        success: 'Meddelande skickat! Vi kontaktar dig snart.',
      },
      hours: 'Öppettider',
      booking: 'Bokning',
    },
    footer: {
      slogan: 'Din bil förtjänar det bästa',
      quickLinks: 'Snabblänkar',
      contact: 'Kontaktuppgifter',
      followUs: 'Följ oss',
      rights: 'Alla rättigheter förbehållna.',
    },
    common: {
      readMore: 'Läs mer',
      learnMore: 'Läs mer',
      freeQuote: 'Gratis värdering',
      seePricing: 'Se prislista',
      callUs: 'Ring oss',
      sendMessage: 'Skicka meddelande',
    },
  },
};
