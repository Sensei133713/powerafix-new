import { useState, useEffect } from 'react';
import { useLanguage } from '@/i18n/LanguageContext';
import { Menu, X, Phone } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export function Header({ currentPage, onPageChange }: HeaderProps) {
  const { t, language, setLanguage } = useLanguage();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: t.nav.home },
    { id: 'services', label: t.nav.services },
    { id: 'gallery', label: t.nav.gallery },
    { id: 'pricing', label: t.nav.pricing },
    { id: 'about', label: t.nav.about },
    { id: 'contact', label: t.nav.contact },
  ];

  const handleNavClick = (pageId: string) => {
    onPageChange(pageId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0a0a0a]/95 backdrop-blur-xl shadow-lg'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2 group"
            >
              <img
                src="/images/powerafix-logo.png"
                alt="PoweraFix"
                className="h-10 md:h-12 w-auto object-contain transition-transform group-hover:scale-105"
              />
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                    currentPage === item.id
                      ? 'text-[#e91e8c] bg-[#e91e8c]/10'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Right side: Language + CTA */}
            <div className="flex items-center gap-3">
              {/* Language Switcher */}
              <div className="lang-switcher">
                <button
                  onClick={() => setLanguage('fi')}
                  className={`lang-btn ${language === 'fi' ? 'active' : ''}`}
                >
                  FI
                </button>
                <button
                  onClick={() => setLanguage('sv')}
                  className={`lang-btn ${language === 'sv' ? 'active' : ''}`}
                >
                  SV
                </button>
              </div>

              {/* CTA Button - Desktop */}
              <button
                onClick={() => handleNavClick('contact')}
                className="hidden md:flex btn-primary items-center gap-2 px-5 py-2.5 rounded-full text-white font-semibold text-sm"
              >
                <Phone className="w-4 h-4" />
                {t.nav.bookNow}
              </button>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-white hover:bg-white/10 transition-colors"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="mobile-menu lg:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="absolute top-4 right-4 p-2 rounded-lg text-white hover:bg-white/10"
          >
            <X className="w-8 h-8" />
          </button>

          <nav className="flex flex-col items-center gap-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`text-2xl font-semibold transition-colors ${
                  currentPage === item.id
                    ? 'text-[#e91e8c]'
                    : 'text-white hover:text-[#e91e8c]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <button
            onClick={() => handleNavClick('contact')}
            className="btn-primary flex items-center gap-2 px-8 py-4 rounded-full text-white font-semibold text-lg mt-4"
          >
            <Phone className="w-5 h-5" />
            {t.nav.bookNow}
          </button>
        </div>
      )}
    </>
  );
}
