import { useLanguage } from '@/i18n/LanguageContext';
import { Phone, Mail, MapPin, Instagram, Facebook, Clock } from 'lucide-react';

interface FooterProps {
  onPageChange: (page: string) => void;
}

export function Footer({ onPageChange }: FooterProps) {
  const { t, language } = useLanguage();

  const quickLinks = [
    { id: 'home', label: t.nav.home },
    { id: 'services', label: t.nav.services },
    { id: 'pricing', label: t.nav.pricing },
    { id: 'gallery', label: t.nav.gallery },
    { id: 'about', label: t.nav.about },
    { id: 'contact', label: t.nav.contact },
  ];

  const hours = language === 'fi' ? [
    { day: 'Maanantai - Perjantai', time: '08:00 - 18:00' },
    { day: 'Lauantai', time: '09:00 - 16:00' },
    { day: 'Sunnuntai', time: 'Sopimuksen mukaan' },
  ] : [
    { day: 'Måndag - Fredag', time: '08:00 - 18:00' },
    { day: 'Lördag', time: '09:00 - 16:00' },
    { day: 'Söndag', time: 'Enligt överenskommelse' },
  ];

  return (
    <footer className="relative bg-[#0a0a0a] border-t border-white/5">
      {/* Top gradient line */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-[#e91e8c] via-[#00d4ff] to-[#e91e8c]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <button
              onClick={() => onPageChange('home')}
              className="flex items-center gap-2 mb-6"
            >
              <img
                src="/images/powerafix-logo.png"
                alt="PoweraFix"
                className="h-12 w-auto object-contain"
              />
            </button>
            <p className="text-gray-400 mb-6">
              {t.footer.slogan}
            </p>
            
            {/* Social Links */}
            <div>
              <h4 className="text-white font-semibold mb-4">{t.footer.followUs}</h4>
              <div className="flex gap-3">
                <a
                  href="https://instagram.com/powerafix1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#e91e8c]/10 flex items-center justify-center text-[#e91e8c] hover:bg-[#e91e8c] hover:text-white transition-all"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="https://facebook.com/powerafix"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#00d4ff]/10 flex items-center justify-center text-[#00d4ff] hover:bg-[#00d4ff] hover:text-white transition-all"
                >
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-6">{t.footer.quickLinks}</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => onPageChange(link.id)}
                    className="text-gray-400 hover:text-[#e91e8c] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold mb-6">{t.footer.contact}</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="tel:+46720256828"
                  className="flex items-center gap-3 text-gray-400 hover:text-[#e91e8c] transition-colors"
                >
                  <Phone className="w-5 h-5 text-[#e91e8c]" />
                  +46 72 025 68 28
                </a>
              </li>
              <li>
                <a
                  href="tel:+358465549098"
                  className="flex items-center gap-3 text-gray-400 hover:text-[#e91e8c] transition-colors"
                >
                  <Phone className="w-5 h-5 text-[#e91e8c]" />
                  +358 46 554 90 98
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@powerafix.com"
                  className="flex items-center gap-3 text-gray-400 hover:text-[#e91e8c] transition-colors"
                >
                  <Mail className="w-5 h-5 text-[#00d4ff]" />
                  info@powerafix.com
                </a>
              </li>
              <li className="flex items-start gap-3 text-gray-400">
                <MapPin className="w-5 h-5 text-[#ff9500] flex-shrink-0 mt-0.5" />
                <span>PoweraFix, Ruotsi / Suomi</span>
              </li>
            </ul>
          </div>

          {/* Opening Hours */}
          <div>
            <h4 className="text-white font-semibold mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#e91e8c]" />
              {t.contact.hours}
            </h4>
            <ul className="space-y-3">
              {hours.map((item, index) => (
                <li key={index} className="flex justify-between text-sm">
                  <span className="text-gray-400">{item.day}</span>
                  <span className="text-white">{item.time}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} PoweraFix. {t.footer.rights}
          </p>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <button className="hover:text-[#e91e8c] transition-colors">
              {language === 'fi' ? 'Tietosuojaseloste' : 'Integritetspolicy'}
            </button>
            <button className="hover:text-[#e91e8c] transition-colors">
              {language === 'fi' ? 'Käyttöehdot' : 'Användarvillkor'}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
