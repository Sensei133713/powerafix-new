import { useLanguage } from '@/i18n/LanguageContext';
import { Star, Quote } from 'lucide-react';

export function Testimonials() {
  const { t, language } = useLanguage();

  const testimonials = language === 'fi' ? [
    {
      id: 1,
      name: 'Mikko K.',
      role: 'Audi A4 omistaja',
      rating: 5,
      text: 'Uskomatonta työtä! Autoni näyttää paremmalta kuin koskaan. Sisäpuhdistus oli perusteellinen ja lopputulos ylitti odotukset.',
      avatar: 'M',
    },
    {
      id: 2,
      name: 'Anna L.',
      role: 'BMW X5 omistaja',
      rating: 5,
      text: 'Erinomainen palvelu alusta loppuun. Keraaminen pinnoite on kestänyt loistavasti ja auto kiiltää yhä kuin uusi.',
      avatar: 'A',
    },
    {
      id: 3,
      name: 'Jukka R.',
      role: 'Mercedes-Benz omistaja',
      rating: 5,
      text: 'Ammattimaista työtä ja ystävällinen palvelu. Suosittelen lämpimästi kaikille, jotka arvostavat laatua.',
      avatar: 'J',
    },
  ] : [
    {
      id: 1,
      name: 'Mikael K.',
      role: 'Audi A4 ägare',
      rating: 5,
      text: 'Otroligt arbete! Min bil ser bättre ut än någonsin. Invändig rengöring var grundlig och resultatet överträffade förväntningarna.',
      avatar: 'M',
    },
    {
      id: 2,
      name: 'Anna L.',
      role: 'BMW X5 ägare',
      rating: 5,
      text: 'Utmärkt service från början till slut. Keramisk beläggning har hållit utmärkt och bilen glänser fortfarande som ny.',
      avatar: 'A',
    },
    {
      id: 3,
      name: 'Johan R.',
      role: 'Mercedes-Benz ägare',
      rating: 5,
      text: 'Professionellt arbete och vänlig service. Jag rekommenderar varmt till alla som uppskattar kvalitet.',
      avatar: 'J',
    },
  ];

  return (
    <section className="section-padding relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0a0a0a]" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#e91e8c]/50 to-transparent" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-[#e91e8c]/5 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-[#e91e8c]/10 text-[#e91e8c] text-sm font-medium mb-4">
            {language === 'fi' ? 'Arvostelut' : 'Omdömen'}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            {t.testimonials.title}
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            {t.testimonials.subtitle}
          </p>
        </div>

        {/* Testimonial Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.id}
              className="relative bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-2xl p-8 border border-white/5 card-hover"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Quote icon */}
              <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-[#e91e8c]/10 flex items-center justify-center">
                <Quote className="w-5 h-5 text-[#e91e8c]" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#ff9500] text-[#ff9500]" />
                ))}
              </div>

              {/* Text */}
              <p className="text-gray-300 leading-relaxed mb-6">
                "{testimonial.text}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#00d4ff] flex items-center justify-center text-white font-bold">
                  {testimonial.avatar}
                </div>
                <div>
                  <div className="text-white font-semibold">{testimonial.name}</div>
                  <div className="text-gray-500 text-sm">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
