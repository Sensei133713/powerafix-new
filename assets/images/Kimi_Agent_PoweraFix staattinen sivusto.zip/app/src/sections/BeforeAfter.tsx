import { useLanguage } from '@/i18n/LanguageContext';
import { useState, useRef, useCallback } from 'react';

export function BeforeAfter() {
  const { t, language } = useLanguage();
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = useCallback(
    (clientX: number) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      setSliderPosition(percentage);
    },
    []
  );

  const handleMouseDown = () => setIsDragging(true);
  const handleMouseUp = () => setIsDragging(false);
  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) handleMove(e.clientX);
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  const galleryItems = [
    {
      id: 1,
      beforeImage: '/images/powerafix-banner.jpg',
      afterImage: '/images/powerafix-swedish.jpg',
      title: 'Sisäpuhdistus',
    },
    {
      id: 2,
      beforeImage: '/images/powerafix-banner2.jpg',
      afterImage: '/images/powerafix-logo-full.png',
      title: 'Ulkopuhdistus',
    },
  ];

  return (
    <section className="section-padding relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-[#0a0a0a]" />
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#00d4ff]/50 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-[#00d4ff]/10 text-[#00d4ff] text-sm font-medium mb-4">
            Galleria
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            {t.beforeAfter.title}
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            {t.beforeAfter.subtitle}
          </p>
        </div>

        {/* Before/After Sliders */}
        <div className="grid md:grid-cols-2 gap-8">
          {galleryItems.map((item) => (
            <div
              key={item.id}
              ref={containerRef}
              className="relative aspect-[4/3] rounded-2xl overflow-hidden cursor-ew-resize select-none"
              onMouseDown={handleMouseDown}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onMouseMove={handleMouseMove}
              onTouchStart={handleMouseDown}
              onTouchEnd={handleMouseUp}
              onTouchMove={handleTouchMove}
            >
              {/* After Image (full) */}
              <div className="absolute inset-0">
                <img
                  src={item.afterImage}
                  alt="After"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 right-4 px-3 py-1 rounded-full bg-[#00d4ff] text-black text-sm font-bold">
                  {t.beforeAfter.after}
                </div>
              </div>

              {/* Before Image (clipped) */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
              >
                <img
                  src={item.beforeImage}
                  alt="Before"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4 px-3 py-1 rounded-full bg-[#e91e8c] text-white text-sm font-bold">
                  {t.beforeAfter.before}
                </div>
              </div>

              {/* Slider Line */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10"
                style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
              >
                {/* Slider Handle */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center">
                  <svg className="w-6 h-6 text-[#0a0a0a]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                  </svg>
                </div>
              </div>

              {/* Title overlay */}
              <div className="absolute top-4 left-4 right-4">
                <h3 className="text-white font-semibold text-lg drop-shadow-lg">
                  {item.title}
                </h3>
              </div>
            </div>
          ))}
        </div>

        {/* Instructions */}
        <p className="text-center text-gray-500 text-sm mt-8">
          {language === 'fi' ? 'Liikuta hiirtä kuvan päällä nähdäksesi eron' : 'Dra musen över bilden för att se skillnaden'}
        </p>
      </div>
    </section>
  );
}
