import { useLanguage } from '@/i18n/LanguageContext';
import { Award, Gem, ShieldCheck } from 'lucide-react';

export function USP() {
  const { t, language } = useLanguage();

  const usps = [
    {
      icon: Award,
      title: t.usp.expertise.title,
      description: t.usp.expertise.description,
      color: '#e91e8c',
    },
    {
      icon: Gem,
      title: t.usp.products.title,
      description: t.usp.products.description,
      color: '#00d4ff',
    },
    {
      icon: ShieldCheck,
      title: t.usp.guarantee.title,
      description: t.usp.guarantee.description,
      color: '#ff9500',
    },
  ];

  return (
    <section className="section-padding relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#1a1a1a] to-[#0a0a0a]" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#e91e8c]/5 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-[#ff9500]/10 text-[#ff9500] text-sm font-medium mb-4">
            {language === 'fi' ? 'Edut' : 'Fördelar'}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            {t.usp.title}
          </h2>
        </div>

        {/* USP Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {usps.map((usp, index) => (
            <div
              key={index}
              className="relative group"
            >
              <div className="relative bg-gradient-to-br from-[#1a1a1a]/80 to-[#0f0f0f]/80 backdrop-blur-sm rounded-2xl p-8 border border-white/5 text-center card-hover overflow-hidden">
                {/* Glow effect */}
                <div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ 
                    background: `radial-gradient(circle at center, ${usp.color}10 0%, transparent 70%)`
                  }}
                />

                {/* Icon */}
                <div 
                  className="relative w-20 h-20 mx-auto mb-6 rounded-2xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110"
                  style={{ backgroundColor: `${usp.color}15` }}
                >
                  <usp.icon 
                    className="w-10 h-10" 
                    style={{ color: usp.color }}
                  />
                </div>

                {/* Content */}
                <h3 className="relative text-xl font-bold text-white mb-4">
                  {usp.title}
                </h3>
                <p className="relative text-gray-400 leading-relaxed">
                  {usp.description}
                </p>

                {/* Bottom accent line */}
                <div 
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-1 rounded-full transition-all duration-300 group-hover:w-1/2"
                  style={{ backgroundColor: usp.color }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: '500+', label: language === 'fi' ? 'Tyytyväistä asiakasta' : 'Nöjda kunder' },
            { value: '5', label: language === 'fi' ? 'Vuoden kokemus' : 'Års erfarenhet' },
            { value: '100%', label: language === 'fi' ? 'Käsityö' : 'Hantverk' },
            { value: '24h', label: language === 'fi' ? 'Nopea palvelu' : 'Snabb service' },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl sm:text-4xl font-bold gradient-text mb-2">
                {stat.value}
              </div>
              <div className="text-gray-400 text-sm">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
