import { useLanguage } from '@/i18n/LanguageContext';
import { Sparkles, Car, Shield, Wrench, ArrowRight } from 'lucide-react';

interface ServicesProps {
  onPageChange: (page: string) => void;
}

export function Services({ onPageChange }: ServicesProps) {
  const { t } = useLanguage();

  const services = [
    {
      id: 'interior',
      icon: Sparkles,
      title: t.services.interior.title,
      description: t.services.interior.description,
      color: '#e91e8c',
      image: '/images/powerafix-banner.jpg',
    },
    {
      id: 'exterior',
      icon: Car,
      title: t.services.exterior.title,
      description: t.services.exterior.description,
      color: '#00d4ff',
      image: '/images/powerafix-swedish.jpg',
    },
    {
      id: 'coating',
      icon: Shield,
      title: t.services.coating.title,
      description: t.services.coating.description,
      color: '#ff9500',
      image: '/images/powerafix-banner2.jpg',
    },
    {
      id: 'special',
      icon: Wrench,
      title: t.services.special.title,
      description: t.services.special.description,
      color: '#C9A961',
      image: '/images/powerafix-logo-full.png',
    },
  ];

  return (
    <section className="section-padding relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#1a1a1a] to-[#0a0a0a]" />
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#e91e8c]/50 to-transparent" />
      <div className="absolute top-1/3 right-0 w-72 h-72 bg-[#e91e8c]/10 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/3 left-0 w-72 h-72 bg-[#00d4ff]/10 rounded-full blur-[100px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-[#e91e8c]/10 text-[#e91e8c] text-sm font-medium mb-4">
            {t.services.title}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            {t.services.title}
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            {t.services.subtitle}
          </p>
        </div>

        {/* Service Cards Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <div
              key={service.id}
              className="group relative bg-gradient-to-br from-[#1a1a1a] to-[#0f0f0f] rounded-2xl overflow-hidden border border-white/5 card-hover"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Card Image */}
              <div className="relative h-48 overflow-hidden">
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                  style={{ 
                    backgroundImage: `url(${service.image})`,
                    opacity: 0.3 
                  }}
                />
                <div 
                  className="absolute inset-0"
                  style={{ 
                    background: `linear-gradient(to bottom, transparent, #1a1a1a)` 
                  }}
                />
                
                {/* Icon */}
                <div 
                  className="absolute top-4 left-4 w-14 h-14 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110"
                  style={{ backgroundColor: `${service.color}20` }}
                >
                  <service.icon 
                    className="w-7 h-7" 
                    style={{ color: service.color }}
                  />
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#e91e8c] transition-colors">
                  {service.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-4">
                  {service.description}
                </p>
                
                <button
                  onClick={() => onPageChange('contact')}
                  className="inline-flex items-center gap-2 text-sm font-medium transition-all group/btn"
                  style={{ color: service.color }}
                >
                  {t.common.readMore}
                  <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                </button>
              </div>

              {/* Hover glow effect */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{ 
                  boxShadow: `inset 0 0 30px ${service.color}20`
                }}
              />
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <div className="text-center mt-12">
          <button
            onClick={() => onPageChange('services')}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-full border-2 border-[#e91e8c]/50 text-[#e91e8c] font-semibold hover:bg-[#e91e8c] hover:text-white transition-all"
          >
            {t.services.cta}
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
}
