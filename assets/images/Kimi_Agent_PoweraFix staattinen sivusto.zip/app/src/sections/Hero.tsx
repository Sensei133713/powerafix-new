import { useLanguage } from '@/i18n/LanguageContext';
import { ArrowRight, Calendar, MessageCircle } from 'lucide-react';

interface HeroProps {
  onPageChange: (page: string) => void;
}

export function Hero({ onPageChange }: HeroProps) {
  const { t } = useLanguage();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/powerafix-banner.jpg"
          alt="PoweraFix Background"
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a]/60 via-[#0a0a0a]/40 to-[#0a0a0a]" />
      </div>

      {/* Animated background elements */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#e91e8c]/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#00d4ff]/10 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 pt-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text Content */}
          <div className="text-center lg:text-left animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#e91e8c]/10 border border-[#e91e8c]/30 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#e91e8c] animate-pulse" />
              <span className="text-[#e91e8c] text-sm font-medium">
                {t.hero.subtitle}
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight mb-6">
              <span className="text-white">{t.hero.title.split(' ').slice(0, 2).join(' ')}</span>
              <br />
              <span className="gradient-text">{t.hero.title.split(' ').slice(2, 4).join(' ')}</span>
              <br />
              <span className="text-white">{t.hero.title.split(' ').slice(4).join(' ')}</span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-xl mx-auto lg:mx-0">
              {t.hero.description}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                onClick={() => onPageChange('contact')}
                className="btn-primary flex items-center justify-center gap-2 px-8 py-4 rounded-full text-white font-semibold text-lg"
              >
                <Calendar className="w-5 h-5" />
                {t.hero.ctaPrimary}
                <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => onPageChange('pricing')}
                className="flex items-center justify-center gap-2 px-8 py-4 rounded-full border-2 border-white/20 text-white font-semibold text-lg hover:bg-white/10 transition-all"
              >
                <MessageCircle className="w-5 h-5" />
                {t.hero.ctaSecondary}
              </button>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 mt-10 pt-8 border-t border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-[#e91e8c]/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#e91e8c]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-300 text-sm">100% Käsityö</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-[#00d4ff]/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#00d4ff]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-300 text-sm">Premium-tuotteet</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-[#ff9500]/20 flex items-center justify-center">
                  <svg className="w-5 h-5 text-[#ff9500]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-300 text-sm">Tyytyväisyystakuu</span>
              </div>
            </div>
          </div>

          {/* Right: Logo/Character */}
          <div className="hidden lg:flex justify-center items-center animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
            <div className="relative">
              <div className="absolute inset-0 bg-[#e91e8c]/30 rounded-full blur-[100px] animate-pulse" />
              <img
                src="/images/powerafix-logo-full.png"
                alt="PoweraFix"
                className="relative z-10 w-full max-w-lg drop-shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-white/30 flex justify-center pt-2">
          <div className="w-1.5 h-3 rounded-full bg-[#e91e8c] animate-pulse" />
        </div>
      </div>
    </section>
  );
}
